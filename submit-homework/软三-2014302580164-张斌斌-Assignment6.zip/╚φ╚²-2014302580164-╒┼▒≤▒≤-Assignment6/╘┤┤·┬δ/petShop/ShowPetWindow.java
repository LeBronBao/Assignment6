package petShop;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class ShowPetWindow {

	protected Shell shell;
	private static Adopt adopt;
	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 */
	public ShowPetWindow(){
		adopt = new Adopt();
	}
	public static Adopt getAdopt() {
		return adopt;
	}
	public static void show() {
		try {
			ShowPetWindow window = new ShowPetWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("宠物信息");
		shell.setLayout(null);
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		lblNewLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblNewLabel.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.ITALIC));
		lblNewLabel.setBounds(10, 231, 88, 20);
		lblNewLabel.setText("JAVA宠物店");
		
		Button dog = new Button(shell, SWT.NONE);
		dog.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 1;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		dog.setBounds(92, 27, 80, 27);
		dog.setText("狗");
		
		Button cat = new Button(shell, SWT.NONE);
		cat.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 2;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		cat.setBounds(264, 27, 80, 27);
		cat.setText("猫");
		
		Button turtle = new Button(shell, SWT.NONE);
		turtle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 3;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		turtle.setBounds(92, 59, 80, 27);
		turtle.setText("乌龟");
		
		Button parrot = new Button(shell, SWT.NONE);
		parrot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 4;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		parrot.setBounds(264, 59, 80, 27);
		parrot.setText("鹦鹉");
		
		Button hamster = new Button(shell, SWT.NONE);
		hamster.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 5;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		hamster.setBounds(92, 91, 80, 27);
		hamster.setText("仓鼠");
		
		Button squirrel = new Button(shell, SWT.NONE);
		squirrel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 6;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		squirrel.setBounds(264, 91, 80, 27);
		squirrel.setText("松鼠");
		
		Button rabbit = new Button(shell, SWT.NONE);
		rabbit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 7;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		rabbit.setBounds(92, 123, 80, 27);
		rabbit.setText("兔子");
		
		Button lizard = new Button(shell, SWT.NONE);
		lizard.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 9;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		lizard.setBounds(264, 123, 80, 27);
		lizard.setText("蜥蜴");
		
		Button snake = new Button(shell, SWT.NONE);
		snake.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 8;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		snake.setBounds(92, 155, 80, 27);
		snake.setText("蛇");
		
		Button fish = new Button(shell, SWT.NONE);
		fish.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 10;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		fish.setBounds(264, 155, 80, 27);
		fish.setText("鱼");
		
		Button myna = new Button(shell, SWT.NONE);
		myna.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 11;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		myna.setBounds(92, 187, 80, 27);
		myna.setText("八哥");
		
		Button canary = new Button(shell, SWT.NONE);
		canary.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				int id = 12;
				PetMessage message = new PetMessage();
				message.getMessage(id);
				
				
				String name = message.getName();
				String eat = message.getEat();
				String drink = message.getDrink();
				String live = message.getLive();
				String hobby = message.getHobby();
				ShowPetMessageWindow messageWindow = new ShowPetMessageWindow(name,eat,drink,live,hobby);
				messageWindow.open();
			}
		});
		canary.setBounds(264, 187, 80, 27);
		canary.setText("金丝雀");
		
		Button adopt = new Button(shell, SWT.NONE);
		adopt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				AdoptWindow adopt = new AdoptWindow();
				adopt.open();
			}
		});
		adopt.setBounds(180, 224, 80, 27);
		adopt.setText("查看");

	}
}
