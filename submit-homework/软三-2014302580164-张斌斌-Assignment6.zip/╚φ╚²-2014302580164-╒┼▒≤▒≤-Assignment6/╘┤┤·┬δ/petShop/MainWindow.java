package petShop;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class MainWindow {

	private String accountID;
	private String password;
	
	protected Shell shlPetshop;
	private Text text;
	private Text text_1;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			MainWindow window = new MainWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlPetshop.open();
		shlPetshop.layout();
		while (!shlPetshop.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlPetshop = new Shell();
		shlPetshop.setSize(450, 300);
		shlPetshop.setText("PetShop");
		shlPetshop.setLayout(null);
		
		Label lblJava = new Label(shlPetshop, SWT.NONE);
		lblJava.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		lblJava.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		lblJava.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 16, SWT.NORMAL));
		lblJava.setAlignment(SWT.CENTER);
		lblJava.setBounds(128, 10, 146, 32);
		lblJava.setText("JAVA宠物店");
		
		Label label = new Label(shlPetshop, SWT.NONE);
		label.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label.setBounds(64, 73, 45, 17);
		label.setText("账号");
		
		Label lblNewLabel = new Label(shlPetshop, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		lblNewLabel.setBounds(64, 111, 45, 17);
		lblNewLabel.setText("密码");
		
		text = new Text(shlPetshop, SWT.BORDER);
		text.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				accountID = text.getText();
			}
		});
		text.setBounds(114, 73, 178, 23);
		
		text_1 = new Text(shlPetshop, SWT.BORDER);
		text_1.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				password = text_1.getText();
			}
		});
		text_1.setBounds(114, 111, 178, 23);
		
		Button btnNewButton = new Button(shlPetshop, SWT.NONE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				ConfirmAccount account = new ConfirmAccount(accountID,password);
				try {
					boolean result = account.confirm();
					if (!result){
						Dialog.showDialog("账号或密码错误");
					}
					else{
						Dialog.showDialog("Welcome  " + accountID);
						//宠物展示界面
						ShowPetWindow.show();
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton.setBounds(159, 158, 80, 27);
		btnNewButton.setText("登陆");
		
		Label lblNewLabel_1 = new Label(shlPetshop, SWT.NONE);
		lblNewLabel_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 9, SWT.ITALIC));
		lblNewLabel_1.setBounds(347, 200, 61, 17);
		lblNewLabel_1.setText("新用户？");
		
		Button button = new Button(shlPetshop, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			//点击注册按钮
			public void mouseUp(MouseEvent e) {
				RegisterWindow.show();
			}
		});
		button.setBounds(327, 227, 80, 27);
		button.setText("快速注册");
		
		Button button_1 = new Button(shlPetshop, SWT.NONE);
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			//点击退出按钮
			public void mouseUp(MouseEvent e) {
				System.exit(0);
			}
		});
		button_1.setBounds(10, 227, 80, 27);
		button_1.setText("退出");

	}
}
