package petShop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 读取宠物信息：name eat drink live hobby<p>
 * 
 * @author 张斌
 * @date 2015年12月10日 
 */
public class PetMessage {
	private String url = "jdbc:mysql://localhost:3306/petshop?user=root&password=root&useUnicode=true&characterEncoding=UTF8";
	private String sql;
	
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	
	public String getName() {
		return name;
	}
	public String getEat() {
		return eat;
	}
	public String getDrink() {
		return drink;
	}
	public String getLive() {
		return live;
	}
	public String getHobby() {
		return hobby;
	}
	
	public void getMessage(int id){
		Connection con = null;
		String driver = "com.mysql.jdbc.Driver";
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			
			Statement stmt = con.createStatement();
			sql = "select * FROM pet WHERE id = '" + id +"'" ;
			ResultSet res = stmt.executeQuery(sql);
			while (res.next()){
				name = res.getString(2);
				eat = res.getString(3);
				drink = res.getString(4);
				live = res.getString(5);
				hobby = res.getString(6);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
