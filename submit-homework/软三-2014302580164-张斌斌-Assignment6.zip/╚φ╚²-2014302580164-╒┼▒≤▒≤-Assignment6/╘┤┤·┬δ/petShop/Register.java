package petShop;
import java.sql.*;

/**
 * 将注册信息写入数据库account表<p>
 * 
 * @author 张斌
 * @date 2015年12月10日 
 */
public class Register {
	private String sql;
	//private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private String url = "jdbc:mysql://localhost:3306/petshop?user=root&password=root&useUnicode=true&characterEncoding=UTF8";

	/**
	 * 在数据库中创建account表
	 * @throws Exception
	 */
	public void creatTable() throws Exception{
		Connection con = null;
		String driver = "com.mysql.jdbc.Driver";
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			Statement stmt = con.createStatement();
			sql = "create table 2014302580164_account(name char(20),accountID char(30),password char(20),eMail text(30),primary key(accountID)) ";
			int result = stmt.executeUpdate(sql);
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public void insert(String name,String accountID,String password,String eMail) throws Exception{
		Connection con = null;
		String driver = "com.mysql.jdbc.Driver";
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			
			sql = "insert into 2014302580164_account values(?,?,?,?)";
			PreparedStatement psql;
			psql = con.prepareStatement(sql);
			psql.setString(1, name);
			psql.setString(2, accountID);
			psql.setString(3, password);
			psql.setString(4, eMail);
			psql.executeUpdate();
		}catch (SQLException e){
			e.printStackTrace();
		}
	}
}
