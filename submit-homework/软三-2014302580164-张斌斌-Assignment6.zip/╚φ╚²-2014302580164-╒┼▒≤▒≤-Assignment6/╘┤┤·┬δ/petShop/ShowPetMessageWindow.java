package petShop;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class ShowPetMessageWindow {

	protected Shell shell;

	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private Text nameText;
	private Text eatText;
	private Text drinkText;
	private Text liveText;
	private Text hobbyText;
	
	private Adopt adopt;
	
	public ShowPetMessageWindow(String name,String eat,String drink,String live,String hobby){
		this.name = name;
		this.eat = eat;
		this.drink = drink;
		this.live = live;
		this.hobby = hobby;
		adopt = ShowPetWindow.getAdopt();
	}


	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(477, 338);
		shell.setText("宠物信息");
		shell.setLayout(null);
		
		Label label = new Label(shell, SWT.NONE);
		label.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label.setBounds(117, 27, 51, 17);
		label.setText("叫什么");
		
		Label label_1 = new Label(shell, SWT.NONE);
		label_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label_1.setBounds(117, 70, 51, 17);
		label_1.setText("吃什么");
		
		Label label_2 = new Label(shell, SWT.NONE);
		label_2.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label_2.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label_2.setBounds(117, 115, 51, 17);
		label_2.setText("喝什么");
		
		Label label_3 = new Label(shell, SWT.NONE);
		label_3.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label_3.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label_3.setBounds(117, 159, 51, 17);
		label_3.setText("住在哪");
		
		Label label_4 = new Label(shell, SWT.NONE);
		label_4.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		label_4.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label_4.setBounds(117, 203, 51, 17);
		label_4.setText("喜欢啥");
		
		Label label_9 = new Label(shell, SWT.NONE);
		label_9.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		label_9.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 10, SWT.ITALIC));
		label_9.setBounds(10, 249, 106, 17);
		label_9.setText("领养代替购买");
		
		Label lblNewLabel_1 = new Label(shell, SWT.NONE);
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 10, SWT.ITALIC));
		lblNewLabel_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblNewLabel_1.setBounds(10, 272, 80, 17);
		lblNewLabel_1.setText("JAVA宠物店");
		
		Button button = new Button(shell, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				adopt.add(name);
				Dialog.showDialog("加入领养");
				shell.dispose();
			}
		});
		button.setBounds(185, 247, 80, 27);
		button.setText("就决定是你了");
		
		nameText = new Text(shell, SWT.BORDER);
		nameText.setText(name);
		nameText.setEditable(false);
		nameText.setBounds(185, 27, 227, 23);
		
		eatText = new Text(shell, SWT.BORDER);
		eatText.setText(eat);
		eatText.setEditable(false);
		eatText.setBounds(185, 70, 227, 23);
		
		drinkText = new Text(shell, SWT.BORDER);
		drinkText.setText(drink);
		drinkText.setEditable(false);
		drinkText.setBounds(185, 115, 227, 23);
		
		liveText = new Text(shell, SWT.BORDER);
		liveText.setText(live);
		liveText.setEditable(false);
		liveText.setBounds(185, 159, 227, 23);
		
		hobbyText = new Text(shell, SWT.BORDER);
		hobbyText.setText(hobby);
		hobbyText.setEditable(false);
		hobbyText.setBounds(185, 203, 227, 23);
		
		Button button_1 = new Button(shell, SWT.NONE);
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				shell.dispose();
			}
		});
		button_1.setBounds(332, 249, 80, 27);
		button_1.setText("再换一个");

	}
}
