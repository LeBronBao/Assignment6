package petShop;
import javax.swing.JOptionPane;
public class Dialog {

	static void showDialog(String mes){
		JOptionPane.showMessageDialog(null, mes);
	}
}
