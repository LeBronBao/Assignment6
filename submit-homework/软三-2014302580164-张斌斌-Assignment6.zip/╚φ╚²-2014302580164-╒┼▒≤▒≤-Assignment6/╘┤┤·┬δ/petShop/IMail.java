package petShop;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * 功能简单说明 <p>
 * 
 * @author 张斌
 * @date 2015年11月24日 
 */
public class IMail  {

	/**
	 * SMTP服务器地址
	 */
	private String host = "smtp.sina.com.cn";
	/**
	 * 邮件会话session
	 */
	private transient Session session;
	/**
	 * 邮件服务器登陆用户名
	 */
	private transient final String username = "13006189880@sina.cn";
	/**
	 * 邮件服务器登陆密码
	 */
	private transient final String password = "zb7871218wei";
	/* 
	 * 链接邮件服务器
	 * 初始化邮件会话session
	 * @override
	 * @see iss.java.mail.IMailService#connect()
	 * @throws MessagingException
	 */
	public void connect() throws MessagingException {
		// TODO 自动生成的方法存根
		//初始化props
		Properties props = new Properties();
		props.put("mail.smtp.host",host);
		props.put("mail.smtp.auth", "true");
		//验证
		IMailAuthentication authentication = new IMailAuthentication(username,password);
		//初始化邮件会话session
		session = Session.getInstance(props,authentication);
	}


	/* 
	 * 发送邮件
	 * @override
	 * @see iss.java.mail.IMailService#send(java.lang.String, java.lang.String, java.lang.Object)
	 * @param recipient 收件人邮箱地址
	 * @param subject 邮件主题
	 * @param content 邮件正文
	 * @throws MessagingException
	 */
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO 自动生成的方法存根
		connect();
		//构造信息体message
		MimeMessage message = new MimeMessage(session);
		//发信人地址
		Address fromAddress = new InternetAddress(new IMailAuthentication(username,password).getUsername());
		message.setFrom(fromAddress);
		//收件人地址
		Address toAddress = new InternetAddress(recipient);
		message.addRecipient(RecipientType.TO, toAddress);
		//设置主题
		message.setSubject(subject);
		//设置正文
		message.setContent(content.toString(),"text/html;charset=utf-8");
		//发送
		Transport.send(message);
	}

	/* 
	 * 询问服务器是否有新邮件到达
	 * @override
	 * @see iss.java.mail.IMailService#listen()
	 * @return
	 * @throws MessagingException
	 */
	public boolean listen() throws MessagingException {
		// TODO 自动生成的方法存根
		connect();
		Store store = session.getStore();
		store.connect();
		// 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
        int count = folder.getUnreadMessageCount();
        folder.close(false);
        store.close();
		return (count > 0? true:false);
	}

	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO 自动生成的方法存根
		String output = "not received";
		connect();
		Store store = session.getStore();
		store.connect();
		//获得folder对象，以“只读”打开
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
		Message [] message = folder.getMessages();
		for (Message i :message){
			if ((sender.equals(i.getFrom().toString())) && (subject.equals(i.getSubject()))){
				output = i.toString();
			}
		}
		return output;
	}
	
}
