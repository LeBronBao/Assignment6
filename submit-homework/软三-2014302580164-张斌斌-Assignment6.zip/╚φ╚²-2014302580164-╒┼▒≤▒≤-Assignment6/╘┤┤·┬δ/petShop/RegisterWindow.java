package petShop;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;

import java.awt.Window;

import javax.swing.JTextField;

import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.ModifyEvent;

public class RegisterWindow {
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	private Text text_4;

	private String name;
	private String accountID;
	private String password;
	private String eMail;
	private int confirmNumber;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void show() {
		try {
			RegisterWindow window = new RegisterWindow();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		final Shell shell = new Shell();
		shell.setSize(485, 407);
		shell.setText("注册");
		
		Label label = new Label(shell, SWT.NONE);
		label.setAlignment(SWT.CENTER);
		label.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		label.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		label.setBounds(188, 2, 112, 27);
		label.setText("欢迎注册");
		
		Label lblJava = new Label(shell, SWT.NONE);
		lblJava.setAlignment(SWT.CENTER);
		lblJava.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		lblJava.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		lblJava.setBounds(188, 35, 112, 27);
		lblJava.setText("JAVA宠物店");
		
		Label label_1 = new Label(shell, SWT.NONE);
		label_1.setAlignment(SWT.CENTER);
		label_1.setBounds(100, 71, 61, 17);
		label_1.setText("姓名");
		
		text = new Text(shell, SWT.BORDER);
		text.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				name = text.getText();
			}
		});
		text.setBounds(167, 68, 192, 23);
		
		Label label_2 = new Label(shell, SWT.NONE);
		label_2.setAlignment(SWT.CENTER);
		label_2.setBounds(100, 113, 61, 17);
		label_2.setText("账号");

		
		Label label_3 = new Label(shell, SWT.NONE);
		label_3.setAlignment(SWT.CENTER);
		label_3.setBounds(100, 158, 61, 17);
		label_3.setText("密码");

		
		Label label_4 = new Label(shell, SWT.NONE);
		label_4.setAlignment(SWT.CENTER);
		label_4.setBounds(100, 197, 61, 17);
		label_4.setText("邮箱");
		Label lblJava_1 = new Label(shell, SWT.NONE);
		lblJava_1.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BORDER));
		lblJava_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 9, SWT.ITALIC));
		lblJava_1.setBounds(167, 225, 192, 17);
		lblJava_1.setText("JAVA宠物店会向此邮箱发送确认码");
		
		Label label_5 = new Label(shell, SWT.NONE);
		label_5.setAlignment(SWT.CENTER);
		label_5.setBounds(100, 251, 61, 17);
		label_5.setText("确认码");
		
		text_1 = new Text(shell, SWT.BORDER);
		text_1.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				accountID = text_1.getText();
			}
		});
		text_1.setBounds(167, 110, 192, 23);
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				password = text_2.getText();
			}
		});
		text_2.setBounds(167, 155, 192, 23);
		
		text_3 = new Text(shell, SWT.BORDER);
		text_3.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				eMail = text_3.getText();
			}
		});
		text_3.setBounds(167, 196, 192, 23);
		
		text_4 = new Text(shell, SWT.BORDER);
		text_4.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent arg0) {
				String s = text_4.getText();
				int confirmNumber = Integer.parseInt(s);
			}
		});
		text_4.setBounds(167, 251, 192, 23);
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				Register register = new Register();
				try {
					//register.creatTable();
					SendEmail EMail = new SendEmail();
					int n = EMail.getRandom();
					if (confirmNumber == n )
					{
						register.insert(name, accountID, password, eMail);
					}
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				String mes = "注册成功";
				Dialog.showDialog(mes);
				shell.dispose();
			}
		});
		btnNewButton.setBounds(167, 299, 80, 27);
		btnNewButton.setText("注册");
		
		Button button = new Button(shell, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				SendEmail EMail = new SendEmail();
				EMail.send(eMail);
				Dialog.showDialog("请查看邮件中的确认码");
			}
		});
		button.setBounds(286, 299, 80, 27);
		button.setText("发送确认邮件");

		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
}
