package petShop;

import java.util.ArrayList;

public class Adopt {
	private ArrayList<String> adoptPet;
	public Adopt(){
		adoptPet = new ArrayList<String>();
	}
	 public void add(String pet){
		 adoptPet.add(pet);
	 }
	 
	public ArrayList<String> getAdoptPet() {
		return adoptPet;
	}
}
