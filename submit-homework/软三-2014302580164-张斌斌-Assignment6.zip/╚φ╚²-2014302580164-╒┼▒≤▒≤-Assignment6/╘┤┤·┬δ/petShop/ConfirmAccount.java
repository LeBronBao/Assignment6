package petShop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 登陆确认   <p>
 * 
 * @author 张斌
 * @date 2015年12月10日 
 */
public class ConfirmAccount {
	private String url = "jdbc:mysql://localhost:3306/petshop?user=root&password=root&useUnicode=true&characterEncoding=UTF8";
	private String sql;
	private String accountID;
	private String password;
	private String confirm_password;
	public ConfirmAccount(String accountID,String password){
		this.accountID = accountID;
		this.password = password;
	}
	public boolean confirm() {
		Connection con = null;
		try{
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			
			Statement stmt = con.createStatement();
			sql = "select * FROM account WHERE accountID = " + "'"+accountID+"'";
			ResultSet res = stmt.executeQuery(sql); 
			while (res.next()){
				confirm_password = res.getString(3);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		if (confirm_password == null)
			return false;
		if (confirm_password.equals(password))
			return true;
		else 
			return false;
	}
}
