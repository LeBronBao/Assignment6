package petShop;

import java.util.Random;
import java.util.Set;

import javax.mail.MessagingException;

import org.reflections.Reflections;



public class SendEmail {

	private int random;
	public int getRandom() {
		return random;
	}
	public void send(String eMail) {
        IMail service = new IMail();
		try {
			
	        service.connect();
	        random = new Random().nextInt(5);
	        service.send(eMail, "确认码","您的确认码是"+random);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}
}
