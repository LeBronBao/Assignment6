package petShop;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;

public class AdoptWindow {

	protected Shell shell;
	private Text text;

	private ArrayList<String> adoptPet;


	/**
	 * Open the window.
	 * @wbp.parser.entryPoint
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("领养");
		
		text = new Text(shell, SWT.MULTI|SWT.BORDER);
		text.setEditable(false);
		text.setBounds(45, 26, 355, 181);
		
		Adopt adopt = ShowPetWindow.getAdopt();
		adoptPet = adopt.getAdoptPet();
		String message;
		StringBuffer s = new StringBuffer();
		for (String pet:adoptPet){
			s.append(pet + "\n");
		}
		message = s.toString();
		text.setText(message);
		
		Button button = new Button(shell, SWT.NONE);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				Dialog.showDialog("领养成功");
				shell.dispose();
			}
		});
		button.setBounds(184, 224, 80, 27);
		button.setText("确定");

	}
}
