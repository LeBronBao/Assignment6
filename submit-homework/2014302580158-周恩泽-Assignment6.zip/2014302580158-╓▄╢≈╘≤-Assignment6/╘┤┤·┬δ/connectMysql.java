package shop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class connectMysql {
	
   public static String name,eat,drink,live,hobby;

	public static void inserData(String setname,String setpassword){
		 String sql ="insert into users(name,password) values ("+setname+","+setpassword+")";//�������
		 connectInfo(sql,true,true);
	}
	
	public static void searchData(){
		String sql ="select * from users";
		 connectInfo(sql,false,true);
		 
	}
	
	public static void customInfo(String setname,String setpassword,String setaddress,String setthing){
		 String sql ="insert into custom(name,tel,address,thing) values ("+setname+","+setpassword+","+setaddress+","+setthing+")";//�������
		 connectInfo(sql,true,true);
	}
	
	public static void petInfo(int i){
		String sql ="select * from pet where id="+i+"";
		 connectInfo(sql,false,false);
		 
	}
	
	public static void connectInfo(String sql,boolean bt,boolean bts){
		String driver = "com.mysql.jdbc.Driver";
        
        String your_passwrod = "123456";
        String userName = "root";
       
        String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
        
        try {
        	//��������
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(url, userName,
                   your_passwrod);
            PreparedStatement ps = conn.prepareStatement(sql);
            if(bt){
             ps.execute();
            }
            if(!bt){
            	ResultSet rs=ps.executeQuery();
            while (rs.next()) {
                if(rs.getString(2).equals(petshop.name)){
                	if(rs.getString(3).equals(petshop.password)){
                		if(bts){
                		new ShopGui().shop();
                		}	
                	}
                }
                 
                if(!bts){
        			name=rs.getString(2);
        			eat=rs.getString(3);
        			drink=rs.getString(4);
        			live=rs.getString(5);
        			hobby=rs.getString(6);
        		}
            }
 
            // �رռ�¼��
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
           }
 
            // �ر�����
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
 
            // �ر����Ӷ���
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
 
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
 }

