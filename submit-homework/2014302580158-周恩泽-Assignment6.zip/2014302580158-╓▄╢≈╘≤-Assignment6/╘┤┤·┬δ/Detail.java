package shop;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Detail extends JFrame {
	private JPanel DetailJPanel;
	private JButton buy;
	JButton[] bt_dt;
    private JLabel noteJLabel;
    private JTextArea Detailtxt;
    String[] str={"dog","cat","turtle","rabbit","snake","lizard","fish","parrot","myna","canary","hamster","squirrel"};
    
    public int i;
    public void Detail(int a){
    	
    	Container contentPane = getContentPane();
		contentPane.setLayout( null );
		
		
		  DetailJPanel = new JPanel();
		  DetailJPanel.setBounds( 150, 30, 200, 250 );
		  DetailJPanel.setBorder(BorderFactory.createEtchedBorder() );       //��ʾһȦ�߶�
		  DetailJPanel.setLayout( null );
	      contentPane.add( DetailJPanel );
	      
	      Detailtxt=new JTextArea();
	      Detailtxt.setBounds(5, 5, 190, 240);
	      Detailtxt.setBorder(BorderFactory.createEtchedBorder() );
	      DetailJPanel.add(Detailtxt);
	      
	      noteJLabel=new JLabel("����������Ӧ�İ�ť:");
	      noteJLabel.setBounds(0,0,150,25);
	      contentPane.add(noteJLabel);
	      
	      bt_dt=new JButton[str.length];
	      for( i=0;i<str.length;i++){
		    	bt_dt[i]=new JButton(str[i]);
		        if(a==1&&i<6){
		        	contentPane.add(bt_dt[i]);
		        	bt_dt[i].setBounds(10,30+i*45,80,25);
		        }
		        if(a==2&&i==6){
		        	contentPane.add(bt_dt[i]);
		        	bt_dt[i].setBounds(10,130,80,25);
		        }
		        
		        if(a==3&&i>6&&i<10){
		        	contentPane.add(bt_dt[i]);
		        	bt_dt[i].setBounds(10,65+(i-6)*45,80,25);
		        }
		        if(a==4&&i>=10&&i<12){
		        	contentPane.add(bt_dt[i]);
		        	bt_dt[i].setBounds(10,120+(i-10)*45,80,25);
		        }
		        
		    	          }
	      bt_dt[0].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(1);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 100yuan \n");
			         }
			});
	      
	      bt_dt[1].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(2);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 33yuan \n");
			         }
			});
	      
	      bt_dt[2].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(3);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 32yuan \n");
			         }
			});
	      
	      bt_dt[3].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(7);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 28yuan \n");
			         }
			});
	      
	      bt_dt[4].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(8);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 38yuan \n");
			         }
			});
	      
	      bt_dt[5].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(9);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 20yuan \n");
			         }
			});
	      
	      bt_dt[6].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(10);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 35yuan \n");
			         }
			});
	      
	      bt_dt[7].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(4);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 40yuan \n");
			         }
			});
	     
	      
	      bt_dt[8].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(11);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 18yuan \n");
			         }
			});
	      
	      bt_dt[9].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(12);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 15yuan \n");
			         }
			});
	      
	      bt_dt[10].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(5);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 30yuan \n");
			         }
			});
	      
	      bt_dt[11].addActionListener(new ActionListener()
			{
			         public void actionPerformed(ActionEvent e)
			         {
			        	 
			        	    	connectMysql.petInfo(6);
			        	       	 Detailtxt.setText("name:"+connectMysql.name+"\n");
			        	       	 Detailtxt.append("eat:"+connectMysql.eat+"\n");
			        	       	 Detailtxt.append("drink:"+connectMysql.drink+"\n");
			        	       	 Detailtxt.append("live:"+connectMysql.live+"\n");
			        	       	 Detailtxt.append("hobby:"+connectMysql.hobby+"\n");
			        	       	 Detailtxt.append("price: 20yuan \n");
			        	    	
			         }
			});
	      
	      buy=new JButton("buy");
	      buy.setBounds(190, 285, 80, 25);
	      
	      contentPane.add(buy);
	      
	      buy.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                	new BuyBus().BuyBus();
	                 }				
	          }
	          );
	      
	      setTitle( "���ֶ���" );  
	      setSize( 380, 350 );
	      setResizable( false ); 
	      setVisible( true );
    }
    
    public void reflect(int j){
    	
    	
    	
    }
}
