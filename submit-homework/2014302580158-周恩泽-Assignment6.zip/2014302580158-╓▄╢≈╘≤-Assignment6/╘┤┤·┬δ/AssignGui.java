package shop;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class AssignGui extends JFrame {
	
	private JPanel userJPanel1;
	private JButton yesJButton,cancelJButton;
	private JTextArea setnametxt,setpasswordtxt;
    private JLabel setnameJLabel,setpasswordJLabel,setnote;
    public static String setname,setpassword;
    
	public void AssignGui(){
        
       
        //��������
        Container contentPane1 = getContentPane();
		contentPane1.setLayout( null );
		
		//�˻�����������봰��
		  userJPanel1 = new JPanel();
	      userJPanel1.setBounds( 35, 50, 300, 120 );
	      userJPanel1.setBorder(BorderFactory.createEtchedBorder() );       //��ʾһȦ�߶�
	      userJPanel1.setLayout( null );
	      contentPane1.add( userJPanel1 );
	      
	      //�˻�������
	      setnametxt=new JTextArea();
	      setnametxt.setBounds(100, 12, 170, 25 );
	      setnametxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setnametxt);
	     
	      setnameJLabel=new JLabel("�����û� ��:");
	      setnameJLabel.setBounds(20,12,80,25);
	      userJPanel1.add(setnameJLabel);
	      
		  //���������
	      setpasswordtxt=new JTextArea();
	      setpasswordtxt.setBounds(100,60,170,25);
	      setpasswordtxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setpasswordtxt);
	 
	      setpasswordJLabel=new JLabel("������  �룺");
	      setpasswordJLabel.setBounds(20,60,80,25);
	      userJPanel1.add(setpasswordJLabel);
	      
	      //��ʾ��ǩ
	      setnote=new JLabel("�û�����������!");
	      setnote.setBounds(20,100,100,25);
	      userJPanel1.add(setnote);
	      
	      
	    //��½��ť������
	      yesJButton=new JButton("ȷ��");
	      yesJButton.setBounds(60,200,80,25);
	      contentPane1.add(yesJButton);
	      yesJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       yesJButtonActionPerformed(event);
	                 }		
	          }
	          );
	      
	    //ȡ����ť����������Ӧ
	         cancelJButton=new JButton("�� ��");
	         cancelJButton.setBounds(210,200,80,25);
	         contentPane1.add(cancelJButton);
	         cancelJButton.addActionListener(
	 
	         new ActionListener()
	         {
	            public void actionPerformed( ActionEvent event )
	            {
	               System.exit(0);        //�˳���½
	            }
	 
	         }
	      );
	      
	      setTitle( "ע�����" );  
	      setSize( 380, 350 );
	      setResizable( false ); 
	      setVisible( true );
	}
	
	private void yesJButtonActionPerformed(ActionEvent event) {
		// TODO �Զ����ɵķ������
		setname=setnametxt.getText();
		setpassword=setpasswordtxt.getText();
		if(setname.equals("")||setpassword.equals("")){
			JOptionPane.showMessageDialog( this,"����д�û���������",
	                 "ע��ʧ��", JOptionPane.ERROR_MESSAGE );
		}else{
		  connectMysql.inserData( setname, setpassword);
		
		 JOptionPane.showMessageDialog( this,"ע��ɹ������˳����µ�¼",
                 "ע��ɹ�", JOptionPane.ERROR_MESSAGE );
		}
	}
	
}
