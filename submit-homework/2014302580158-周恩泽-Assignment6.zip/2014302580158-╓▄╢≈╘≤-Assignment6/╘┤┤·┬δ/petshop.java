package shop;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;



public class petshop extends JFrame
{
	 private JPanel userJPanel;
     
     private JButton okJButton,cancelJButton,assginButton;
     private JLabel nameJLabel,passwordJLabel,note;
     private JPasswordField passwordJPasswordField;
     private JTextArea nametxt,setnametxt,setpasswordtxt;
     
     public static String name;
     public static String password;
     private String user;
     
	public  petshop(){
		
		 createUserInterface();     //���õ�½����
		
	}
	
	private void createUserInterface(){
		
		Container contentPane = getContentPane();
		contentPane.setLayout( null );
		
		//�˻�����������봰��
		  userJPanel = new JPanel();
	      userJPanel.setBounds( 35, 50, 300, 120 );
	      userJPanel.setBorder(BorderFactory.createEtchedBorder() );       //��ʾһȦ�߶�
	      userJPanel.setLayout( null );
	      contentPane.add( userJPanel );
	      
	      //�˻�������
	      nametxt=new JTextArea();
	      nametxt.setBounds(100, 12, 170, 25 );
	      nametxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel.add(nametxt);
	     
	      nameJLabel=new JLabel("�û� ����");
	      nameJLabel.setBounds(20,12,80,25);
	      userJPanel.add(nameJLabel);
	      
		  //���������
	      passwordJPasswordField=new JPasswordField();
	      passwordJPasswordField.setBounds(100,60,170,25);
	      userJPanel.add(passwordJPasswordField);
	 
	      passwordJLabel=new JLabel("��  �룺");
	      passwordJLabel.setBounds(20,60,80,25);
	      userJPanel.add(passwordJLabel);
	      
	      
	      //��½��ť������
	      okJButton=new JButton("��  ½");
	      okJButton.setBounds(60,200,80,25);
	      contentPane.add(okJButton);
	      okJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       okJButtonActionPerformed(event);
	                 }		
	          }
	          );
	      
	         //ȡ����ť����������Ӧ
	         cancelJButton=new JButton("ȡ  ��");
	         cancelJButton.setBounds(210,200,80,25);
	         contentPane.add(cancelJButton);
	         cancelJButton.addActionListener(
	 
	         new ActionListener()
	         {
	            public void actionPerformed( ActionEvent event )
	            {
	               System.exit(0);        //�˳���½
	            }
	 
	         }
	      );
	         
	       //ע�ᰴť������
	       assginButton=new JButton("ע��");
	       assginButton.setBounds(60,250,80,25);
		   contentPane.add(assginButton);
		   assginButton.addActionListener(
		                new ActionListener()
		          {
		                public void actionPerformed(ActionEvent event)
		                 {
		                	assginButtonActionPerformed(event);
		                 }		
		          }
		          );
	      
	      setTitle( "PetShop��½����" );  
	      setSize( 380, 350 );
	      setResizable( false );  
	      }
	
    //��½��ť����Ӧ����
	@SuppressWarnings("deprecation")
	private void okJButtonActionPerformed(ActionEvent event) {
		// TODO �Զ����ɵķ������
		name=nametxt.getText();
		password=passwordJPasswordField.getText();
		if(name.equals("")||password.equals("")){
			JOptionPane.showMessageDialog( this,"�������û���������",
	                 "��¼ʧ��", JOptionPane.ERROR_MESSAGE );
		}else{
		  connectMysql.searchData();
		
		 JOptionPane.showMessageDialog( this,"��¼�ɹ�",
                 "��¼�ɹ������Ե�", JOptionPane.ERROR_MESSAGE );
		}
	}
	
	//ע�ᰴť����Ӧ����
	
	private void assginButtonActionPerformed(ActionEvent event) {
		// TODO �Զ����ɵķ������
		new AssignGui().AssignGui();
		setVisible(false);
	}	
	
	//ע�ᴰ��
	

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		JFrame.setDefaultLookAndFeelDecorated(true);
        petshop mylogin = new petshop();
        mylogin.setVisible( true );
        mylogin.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

	}

}
