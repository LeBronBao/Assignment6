package shop;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class BuyBus extends JFrame{
	private JPanel userJPanel1;
	private JButton yesJButton,cancelJButton;
	private JTextArea setnametxt,setpasswordtxt,setaddresstxt,setthingtxt;
    private JLabel setnameJLabel,setpasswordJLabel,setaddressLabel,setthingLabel,setnote;
    public static String setname,tel,setaddress,setthing,setpassword;
    
	public void BuyBus(){
        
       
        //��������
        Container contentPane1 = getContentPane();
		contentPane1.setLayout( null );
		
		//�˻�����������봰��
		  userJPanel1 = new JPanel();
	      userJPanel1.setBounds( 35, 50, 300, 200 );
	      userJPanel1.setBorder(BorderFactory.createEtchedBorder() );       //��ʾһȦ�߶�
	      userJPanel1.setLayout( null );
	      contentPane1.add( userJPanel1 );
	      
	      //�˻�������
	      setnametxt=new JTextArea();
	      setnametxt.setBounds(100, 12, 170, 25 );
	      setnametxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setnametxt);
	     
	      setnameJLabel=new JLabel("������ ����:");
	      setnameJLabel.setBounds(20,12,80,25);
	      userJPanel1.add(setnameJLabel);
	      
		  //���������
	      setpasswordtxt=new JTextArea();
	      setpasswordtxt.setBounds(100,60,170,25);
	      setpasswordtxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setpasswordtxt);
	 
	      setpasswordJLabel=new JLabel("��ϵ��ʽ��");
	      setpasswordJLabel.setBounds(20,60,80,25);
	      userJPanel1.add(setpasswordJLabel);
	      
	      //��ַ
	      setaddresstxt=new JTextArea();
	      setaddresstxt.setBounds(100,108,170,25);
	      setaddresstxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setaddresstxt);
	 
	      setaddressLabel=new JLabel("��ַ��");
	      setaddressLabel.setBounds(20,108,80,25);
	      userJPanel1.add(setaddressLabel);
	      
	      //������Ʒ����
	      setthingtxt=new JTextArea();
	      setthingtxt.setBounds(100,156,170,25);
	      setthingtxt.setBorder(BorderFactory.createEtchedBorder() );
	      userJPanel1.add(setthingtxt);
	 
	      setthingLabel=new JLabel("������Ʒ��");
	      setthingLabel.setBounds(20,156,80,25);
	      userJPanel1.add(setthingLabel);
	      
	      //��ʾ��ǩ
	      setnote=new JLabel("��ľ�������!");
	      setnote.setBounds(20,180,100,25);
	      userJPanel1.add(setnote);
	      
	      
	    //��½��ť������
	      yesJButton=new JButton("ȷ��");
	      yesJButton.setBounds(60,260,80,25);
	      contentPane1.add(yesJButton);
	      yesJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       yesJButtonActionPerformed(event);
	                 }		
	          }
	          );
	      
	    //ȡ����ť����������Ӧ
	         cancelJButton=new JButton("ȡ��");
	         cancelJButton.setBounds(210,260,80,25);
	         contentPane1.add(cancelJButton);
	         cancelJButton.addActionListener(
	 
	         new ActionListener()
	         {
	            public void actionPerformed( ActionEvent event )
	            {
	               System.exit(0);        //�˳���½
	            }
	 
	         }
	      );
	      
	      setTitle( "ע�����" );  
	      setSize( 380, 350 );
	      setResizable( false ); 
	      setVisible( true );
	}
	
	private void yesJButtonActionPerformed(ActionEvent event) {
		// TODO �Զ����ɵķ������
		setname=setnametxt.getText();
		setpassword=setpasswordtxt.getText();
		setaddress=setaddresstxt.getText();
		setthing=setthingtxt.getText();
		if(setname.equals("")||setpassword.equals("")||setaddress.equals("")||setthing.equals("")){
			JOptionPane.showMessageDialog( this,"����д��������ϵ��ʽ�͹�����Ʒ���ַ",
	                 "����ʧ��", JOptionPane.ERROR_MESSAGE );
		}else{
		  connectMysql.customInfo( setname, setpassword,setaddress,setthing);
		
		 JOptionPane.showMessageDialog( this,"����ɹ�",
                 "����ɹ�", JOptionPane.ERROR_MESSAGE );
		}
	}
	

}
