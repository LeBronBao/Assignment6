package shop;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ShopGui extends JFrame {
	
	private JPanel shopJPanel;
	 private JButton paJButton,swimJButton,birdJButton,waJButton;
	 private JLabel noteJLabel,passwordJLabel,note;
	public  void shop(){
		
		Container contentPane = getContentPane();
		contentPane.setLayout( null );
		
		//�̵���ҳ
		  shopJPanel = new JPanel();
	      shopJPanel.setBounds( 35, 50, 300, 120 );
	      shopJPanel.setBorder(BorderFactory.createEtchedBorder() );       //��ʾһȦ�߶�
	      shopJPanel.setLayout( null );
	      contentPane.add( shopJPanel );
	      
	      noteJLabel=new JLabel("��ѡ������Ҫ�ĳ�������:");
	      noteJLabel.setBounds(0,30,150,25);
	      contentPane.add(noteJLabel);
	      
	    //��������ﰴť������
	      paJButton=new JButton("������");
	      paJButton.setBounds(20,20,80,25);
	      shopJPanel.add(paJButton);
	      paJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       paJButtonActionPerformed(event);
	                 }		
	          }
	          );
	      
	    //��������ﰴť������
	      swimJButton=new JButton("����");
	      swimJButton.setBounds(20,80,80,25);
	      shopJPanel.add(swimJButton);
	      swimJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       swimJButtonActionPerformed(event);
	                 }

						
	          }
	          );
	      
	    //������ﰴť������
	      birdJButton=new JButton("����");
	      birdJButton.setBounds(200,20,80,25);
	      shopJPanel.add(birdJButton);
	      birdJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       birdJButtonActionPerformed(event);
	                 }

						
	          }
	          );
	      
	    //�ڶ�����ﰴť������
	      waJButton=new JButton("�ڶ���");
	      waJButton.setBounds(200,80,80,25);
	      shopJPanel.add(waJButton);
	      waJButton.addActionListener(
	                new ActionListener()
	          {
	                public void actionPerformed(ActionEvent event)
	                 {
	                       waJButtonActionPerformed(event);
	                 }

						
	          }
	          );
		
		  setTitle( "shop��ҳ" );  
	      setSize( 380, 350 );
	      setResizable( false ); 
	      setVisible( true );
	}
	private void paJButtonActionPerformed(ActionEvent event) {
		new Detail().Detail(1);
	}
	
	private void swimJButtonActionPerformed(ActionEvent event) {
		// TODO �Զ����ɵķ������
		new Detail().Detail(2);
		
	}	
	
	private void birdJButtonActionPerformed(ActionEvent event) {
		new Detail().Detail(3);
	}
	
	private void waJButtonActionPerformed(ActionEvent event) {
		new Detail().Detail(4);
	}

}
