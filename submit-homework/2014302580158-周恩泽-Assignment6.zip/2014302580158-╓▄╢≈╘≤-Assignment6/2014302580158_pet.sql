/*
Navicat MySQL Data Transfer

Source Server         : mylocalsql
Source Server Version : 50709
Source Host           : localhost:3306
Source Database       : my_schema

Target Server Type    : MYSQL
Target Server Version : 50709
File Encoding         : 65001

Date: 2015-12-09 16:03:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `pet`
-- ----------------------------
DROP TABLE IF EXISTS `pet`;
CREATE TABLE `pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pet
-- ----------------------------
INSERT INTO `pet` VALUES ('1', 'dog', 'bone', 'water', 'ground', 'play');
INSERT INTO `pet` VALUES ('2', 'cat', 'fish', 'milk', 'roof', 'hug');
INSERT INTO `pet` VALUES ('3', 'turtle', 'fish,shrimp', 'sea water', 'sea water', 'bask');
INSERT INTO `pet` VALUES ('4', 'parrot', 'nuts,seeds', 'water', 'tree', 'fly');
INSERT INTO `pet` VALUES ('5', 'hamster', 'Sunflower seed', 'water', 'corner', 'eat');
INSERT INTO `pet` VALUES ('6', 'squirrel', 'pine cone', 'water', 'tree hole,underground', 'play');
INSERT INTO `pet` VALUES ('7', 'rabbit', 'carrot', 'water', 'grassland,underground', 'eat');
INSERT INTO `pet` VALUES ('8', 'snake', 'mouse', 'water', 'hole', 'bask');
INSERT INTO `pet` VALUES ('9', 'lizard', 'bug', 'water', 'tree', 'bask');
INSERT INTO `pet` VALUES ('10', 'fish', 'aquatic plant', 'water', 'water', 'swim');
INSERT INTO `pet` VALUES ('11', 'myna', 'earthworm', 'water', 'tree', 'fly');
INSERT INTO `pet` VALUES ('12', 'canary', 'millet', 'water', 'tree', 'sing');
